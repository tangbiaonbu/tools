package com.example.demo.configuration;

/**
 * Created by as on 09.07.2018.
 */
public class SparkConfiguartion {
    public static final int MAX_RUNNING_TASKS = 1;
}
