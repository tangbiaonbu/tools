package com.example.demo.dto;

/**
 * Created by as on 07.07.2018.
 */
public class MasterUrlDto {
    private String masterUrl;

    public MasterUrlDto(String masterUrl) {
        this.masterUrl = masterUrl;
    }

    public String getMasterUrl() {
        return masterUrl;
    }

    public void setMasterUrl(String masterUrl) {
        this.masterUrl = masterUrl;
    }
}
