import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.hikdata.entities.TagCatalog;

import java.util.*;

public class catalog {
    public static void main(String[] args) {
        List<TagCatalog> returanList = new ArrayList<>();
        TagCatalog tagCatalog1 = new TagCatalog();
        tagCatalog1.setId(1);
        tagCatalog1.setLevelId(1);
        tagCatalog1.setChineseName("武器装备");
        tagCatalog1.setEnglishName("weapon");
        tagCatalog1.setUuid("775db528-7860-4a59-a53e-b07f3985d777");
        returanList.add(tagCatalog1);

        TagCatalog tagCatalog2 = new TagCatalog();
        tagCatalog2.setId(2);
        tagCatalog2.setLevelId(1);
        tagCatalog2.setChineseName("人员");
        tagCatalog2.setEnglishName("person");
        tagCatalog2.setUuid("3e4fc3d1abbc40c095e4508e26f6dce6");
        returanList.add(tagCatalog2);

        TagCatalog tagCatalog3 = new TagCatalog();
        tagCatalog3.setId(3);
        tagCatalog3.setLevelId(2);
        tagCatalog3.setChineseName("基础标签");
        tagCatalog3.setEnglishName("basic_tag");
        tagCatalog3.setUuid("05cf63a540f04ab39c6ed289e8e85422");
        tagCatalog3.setParentId("775db528-7860-4a59-a53e-b07f3985d777");
        returanList.add(tagCatalog3);

        TagCatalog tagCatalog4 = new TagCatalog();
        tagCatalog4.setId(4);
        tagCatalog4.setLevelId(2);
        tagCatalog4.setChineseName("业务标签");
        tagCatalog4.setEnglishName("bussiness_tag");
        tagCatalog4.setUuid("aed641da4d5e44c6a52e1db1be6bb994");
        tagCatalog4.setParentId("775db528-7860-4a59-a53e-b07f3985d777");
        returanList.add(tagCatalog4);

        TagCatalog tagCatalog5 = new TagCatalog();
        tagCatalog5.setId(5);
        tagCatalog5.setLevelId(3);
        tagCatalog5.setChineseName("时间");
        tagCatalog5.setEnglishName("date");
        tagCatalog5.setUuid("47e2ce4876d24ce79ff7df029d43b512");
        tagCatalog5.setParentId("05cf63a540f04ab39c6ed289e8e85422");
        tagCatalog5.setLevelTwoType("date");
        returanList.add(tagCatalog5);

        TagCatalog tagCatalog6 = new TagCatalog();
        tagCatalog6.setId(6);
        tagCatalog6.setLevelId(3);
        tagCatalog6.setChineseName("地点");
        tagCatalog6.setEnglishName("coordinate");
        tagCatalog6.setUuid("e3caa86281a04cbf81265888fa5767ba");
        tagCatalog6.setParentId("05cf63a540f04ab39c6ed289e8e85422");
        tagCatalog6.setLevelTwoType("varchar");
        returanList.add(tagCatalog6);

        JSONArray result = new JSONArray();
        for (TagCatalog next : returanList) {
            if (next.getLevelId() == 1) {
                JSONObject first = new JSONObject();
                String uuid1 = next.getUuid();
                first.put("levelId", next.getLevelId());
                first.put("ParentId", next.getParentId());
                first.put("uuid", uuid1);
                first.put("chineseName", next.getChineseName());
                first.put("englishName", next.getEnglishName());
                first.put("id", next.getId());
                first.put("levelTwoType", next.getLevelTwoType());
                first.put("projectId", next.getProjectId());
                first.put("sortField", next.getSortField());
                first.put("introduction", next.getIntroduction());
                JSONArray firstArray = new JSONArray();
                for (TagCatalog tagFirstSon : returanList) {
                    JSONObject second = new JSONObject();
                    if (tagFirstSon.getLevelId() == 2 && tagFirstSon.getParentId().equals(uuid1)) {
                        String uuid2 = tagFirstSon.getUuid();
                        second.put("levelId", next.getLevelId());
                        second.put("ParentId", next.getParentId());
                        second.put("uuid", uuid2);
                        second.put("chineseName", next.getChineseName());
                        second.put("englishName", next.getEnglishName());
                        second.put("id", next.getId());
                        second.put("levelTwoType", next.getLevelTwoType());
                        second.put("projectId", next.getProjectId());
                        second.put("sortField", next.getSortField());
                        second.put("introduction", next.getIntroduction());
                        JSONArray secondArray = new JSONArray();
                        for (TagCatalog tagsecondSon : returanList) {
                            JSONObject third = new JSONObject();
                            if (tagFirstSon.getLevelId() == 3 && tagsecondSon.getParentId().equals(uuid2)) {
                                String uuid3 = tagFirstSon.getUuid();
                                third.put("levelId", next.getLevelId());
                                third.put("ParentId", next.getParentId());
                                third.put("uuid", uuid3);
                                third.put("chineseName", next.getChineseName());
                                third.put("englishName", next.getEnglishName());
                                third.put("id", next.getId());
                                third.put("levelTwoType", next.getLevelTwoType());
                                third.put("projectId", next.getProjectId());
                                third.put("sortField", next.getSortField());
                                third.put("introduction", next.getIntroduction());
                                secondArray.add(third);
                            }
                            second.put("secondLevel",secondArray);
                        }
                        firstArray.add(second);
                    }
                    first.put("firstLevel",firstArray);
                }
                result.add(first);
            }
        }
    }
}


