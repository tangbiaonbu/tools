public class sjdajd {
    public static void main(String[] args) {
        System.out.println(Float.parseFloat("1.205"));
    }
}
