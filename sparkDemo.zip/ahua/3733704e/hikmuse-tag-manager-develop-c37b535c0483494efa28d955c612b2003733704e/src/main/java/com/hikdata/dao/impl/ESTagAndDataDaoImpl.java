package com.hikdata.dao.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.hikdata.TagManagerServer;
import com.hikdata.dao.ESTagAndDataDao;
import com.hikdata.entities.AddDataTags;
import com.hikdata.entities.CatalogSearch;
import com.hikdata.entities.MuiltiTagSearch;
import org.apache.lucene.search.join.ScoreMode;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.get.GetRequest;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.client.Client;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.NestedQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Repository
public class ESTagAndDataDaoImpl implements ESTagAndDataDao {
    private final static String VIDEO_META_INDEX = "video_metadata";
    private final static String AUDIO_META_INDEX = "audio_metadata";
    private final static String PICTURE_META_INDEX = "picture_metadata";
    private final static String DOCUMENT_META_INDEX = "document_metadata";
    private final static String OTHER_META_INDEX = "other_metadata";
    private final static String TABLE_META_INDEX = "table_metadata";
    private final static String METALIB_TYPE = "info";


    @Override
    public SearchResponse searchByMultiTags(MuiltiTagSearch muiltiTagSearch) {
        JSONObject searchTags = muiltiTagSearch.getMuiltiTags();
        String index = muiltiTagSearch.getIndex();
        int pageSize = muiltiTagSearch.getPageSize();
        int PageNum = muiltiTagSearch.getPageNum();
        String searchKeyWord = muiltiTagSearch.getSearchKeyWord();
        Client client = TagManagerServer.getClient();
        //构建查询语句
        BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
        if (searchTags != null) {
            for (String field : searchTags.keySet()) {
                JSONArray value = searchTags.getJSONArray(field);
                //es存储的格式为"uuid":["value1","value2"]
                for (Object valueSon : value) {
                    boolQueryBuilder.must(QueryBuilders.matchQuery(field, valueSon));
                }
            }
        }
        if (searchKeyWord != null) {
            boolQueryBuilder.must(QueryBuilders.wildcardQuery("file_name.keyword", "*" + searchKeyWord + "*"));
        }
        if (muiltiTagSearch.getGt() != null && muiltiTagSearch.getLt() != null) {
            RangeQueryBuilder rangeQueryBuilder = QueryBuilders.rangeQuery("ETLTime")
                    .gte(muiltiTagSearch.getGt())
                    .lte(muiltiTagSearch.getLt());
            boolQueryBuilder.must(rangeQueryBuilder);
        }
        SearchRequestBuilder searchRequestBuilder;
        if (index != null) {
            //在固定的index搜索
            searchRequestBuilder = client.prepareSearch(index).setTypes(METALIB_TYPE);
        } else {
            //在所有index检索
            searchRequestBuilder = client.prepareSearch(new String[]{VIDEO_META_INDEX, AUDIO_META_INDEX,
                    PICTURE_META_INDEX, DOCUMENT_META_INDEX, OTHER_META_INDEX, TABLE_META_INDEX}).
                    setTypes(new String[]{METALIB_TYPE, METALIB_TYPE, METALIB_TYPE, METALIB_TYPE, METALIB_TYPE,
                            METALIB_TYPE});
        }
        SearchResponse searchResponse = searchRequestBuilder.setQuery(boolQueryBuilder)
                .setSize(pageSize)
                .setFrom((PageNum - 1) * pageSize)
                .addSort("ETLTime", SortOrder.DESC)
                .get();
        client.close();
        return searchResponse;
    }

    @Override
    public Integer addDataTags(AddDataTags addDataTags) {
        Client client = TagManagerServer.getClient();
        BulkRequest bulkRequest = new BulkRequest();
        if ((addDataTags.getPicture() != null)) {
            JSONObject tags = addDataTags.getTags();
            for (String metaId : addDataTags.getPicture()) {
                GetRequest getRequest = new GetRequest(PICTURE_META_INDEX, METALIB_TYPE, metaId);
                GetResponse response = client.get(getRequest).actionGet();
                for (String tagFiled : tags.keySet()) {
                    Map<String, Object> data = response.getSourceAsMap();
                    if (data.containsKey(tagFiled)) {
                        ArrayList old = (ArrayList) data.get(tagFiled);
                        for (Object a : old) {
                            JSONArray newField = tags.getJSONArray(tagFiled);
                            if (!newField.contains(a)) {
                                newField.add(a);
                            }
                            tags.replace(tagFiled, newField);
                        }
                    }
                }
                UpdateRequest updateRequest = new UpdateRequest();
                updateRequest.index(PICTURE_META_INDEX).type(METALIB_TYPE).id(metaId).doc(tags);
                bulkRequest.add(updateRequest);
            }
        }
        if (addDataTags.getDocument() != null) {
            JSONObject tags = addDataTags.getTags();
            for (String metaId : addDataTags.getDocument()) {
                GetRequest getRequest = new GetRequest(DOCUMENT_META_INDEX, METALIB_TYPE, metaId);
                GetResponse response = client.get(getRequest).actionGet();
                for (String tagFiled : tags.keySet()) {
                    Map<String, Object> data = response.getSourceAsMap();
                    if (data.containsKey(tagFiled)) {
                        ArrayList old = (ArrayList) data.get(tagFiled);
                        for (Object a : old) {
                            JSONArray newField = tags.getJSONArray(tagFiled);
                            if (!newField.contains(a)) {
                                newField.add(a);
                            }
                            tags.replace(tagFiled, newField);
                        }
                    }
                }
                UpdateRequest updateRequest = new UpdateRequest();
                updateRequest.index(DOCUMENT_META_INDEX).type(METALIB_TYPE).id(metaId).doc(tags);
                bulkRequest.add(updateRequest);
            }
        }

        if (addDataTags.getAudio() != null) {
            JSONObject tags = addDataTags.getTags();
            for (String metaId : addDataTags.getAudio()) {
                GetRequest getRequest = new GetRequest(AUDIO_META_INDEX, METALIB_TYPE, metaId);
                GetResponse response = client.get(getRequest).actionGet();
                for (String tagFiled : tags.keySet()) {
                    Map<String, Object> data = response.getSourceAsMap();
                    if (data.containsKey(tagFiled)) {
                        ArrayList old = (ArrayList) data.get(tagFiled);
                        for (Object a : old) {
                            JSONArray newField = tags.getJSONArray(tagFiled);
                            if (!newField.contains(a)) {
                                newField.add(a);
                            }
                            tags.replace(tagFiled, newField);
                        }
                    }
                }
                UpdateRequest updateRequest = new UpdateRequest();
                updateRequest.index(AUDIO_META_INDEX).type(METALIB_TYPE).id(metaId).doc(tags);
                bulkRequest.add(updateRequest);
            }
        }

        if (addDataTags.getVideo() != null) {
            JSONObject tags = addDataTags.getTags();
            for (String metaId : addDataTags.getVideo()) {
                GetRequest getRequest = new GetRequest(VIDEO_META_INDEX, METALIB_TYPE, metaId);
                GetResponse response = client.get(getRequest).actionGet();
                for (String tagFiled : tags.keySet()) {
                    Map<String, Object> data = response.getSourceAsMap();
                    if (data.containsKey(tagFiled)) {
                        ArrayList old = (ArrayList) data.get(tagFiled);
                        for (Object a : old) {
                            JSONArray newField = tags.getJSONArray(tagFiled);
                            if (!newField.contains(a)) {
                                newField.add(a);
                            }
                            tags.replace(tagFiled, newField);
                        }
                    }
                }
                UpdateRequest updateRequest = new UpdateRequest();
                updateRequest.index(VIDEO_META_INDEX).type(METALIB_TYPE).id(metaId).doc(tags);
                bulkRequest.add(updateRequest);
            }
        }

        if (addDataTags.getOther() != null) {
            JSONObject tags = addDataTags.getTags();
            for (String metaId : addDataTags.getOther()) {
                GetRequest getRequest = new GetRequest(OTHER_META_INDEX, METALIB_TYPE, metaId);
                GetResponse response = client.get(getRequest).actionGet();
                for (String tagFiled : tags.keySet()) {
                    Map<String, Object> data = response.getSourceAsMap();
                    if (data.containsKey(tagFiled)) {
                        ArrayList old = (ArrayList) data.get(tagFiled);
                        for (Object a : old) {
                            JSONArray newField = tags.getJSONArray(tagFiled);
                            if (!newField.contains(a)) {
                                newField.add(a);
                            }
                            tags.replace(tagFiled, newField);
                        }
                    }
                }
                UpdateRequest updateRequest = new UpdateRequest();
                updateRequest.index(OTHER_META_INDEX).type(METALIB_TYPE).id(metaId).doc(tags);
                bulkRequest.add(updateRequest);
            }
        }

        if (addDataTags.getTable() != null) {
            JSONObject tags = addDataTags.getTags();
            for (String metaId : addDataTags.getTable()) {
                GetRequest getRequest = new GetRequest(TABLE_META_INDEX, METALIB_TYPE, metaId);
                GetResponse response = client.get(getRequest).actionGet();
                for (String tagFiled : tags.keySet()) {
                    Map<String, Object> data = response.getSourceAsMap();
                    if (data.containsKey(tagFiled)) {
                        ArrayList old = (ArrayList) data.get(tagFiled);
                        for (Object a : old) {
                            JSONArray newField = tags.getJSONArray(tagFiled);
                            if (!newField.contains(a)) {
                                newField.add(a);
                            }
                            tags.replace(tagFiled, newField);
                        }
                    }
                }
                UpdateRequest updateRequest = new UpdateRequest();
                updateRequest.index(TABLE_META_INDEX).type(METALIB_TYPE).id(metaId).doc(tags);
                bulkRequest.add(updateRequest);
            }
        }
        client.bulk(bulkRequest);
        client.close();
        return 1;
    }

    @Override
    public SearchResponse searchByCatelog(CatalogSearch catalogSearch) {
        Client client = TagManagerServer.getClient();
        List<String> catalogIds = catalogSearch.getCatalogId();
        String index = catalogSearch.getIndex();
        int pageNum = catalogSearch.getPageNum();
        int pageSize = catalogSearch.getPageSize();
        BoolQueryBuilder builder = new BoolQueryBuilder();
        builder.must(QueryBuilders.nestedQuery("premis", QueryBuilders.termsQuery("premis.catalogueID",
                catalogIds), ScoreMode.None));
        SearchRequestBuilder searchRequestBuilder;
        if (index != null) {
            //在固定的index搜索
            searchRequestBuilder = client.prepareSearch(index).setTypes(METALIB_TYPE);
        } else {
            //在所有index检索
            searchRequestBuilder = client.prepareSearch(new String[]{VIDEO_META_INDEX, AUDIO_META_INDEX,
                    PICTURE_META_INDEX, DOCUMENT_META_INDEX, OTHER_META_INDEX, TABLE_META_INDEX}).
                    setTypes(new String[]{METALIB_TYPE, METALIB_TYPE, METALIB_TYPE, METALIB_TYPE, METALIB_TYPE,
                            METALIB_TYPE});
        }
        SearchResponse searchResponse = searchRequestBuilder.setQuery(builder)
                .setSize(pageSize)
                .setFrom((pageNum - 1) * pageSize)
                .addSort("ETLTime", SortOrder.DESC)
                .get();
//        System.out.println(searchResponse);
        client.close();
        return searchResponse;
    }
}


