package com.hikdata.entities;


import com.alibaba.fastjson.JSONObject;

import java.util.List;

public class AddDataTags {


    //批量选择数据，生成的metaId List 用于更新
    private List<String> picture;
    private List<String> document;
    private List<String> audio;
    private List<String> video;
    private List<String> other;
    private List<String> table;

    //补录的标签值，以uuid：vlue的形式存放
    private JSONObject tags;

    public List<String> getPicture() {
        return picture;
    }

    public void setPicture(List<String> picture) {
        this.picture = picture;
    }

    public List<String> getDocument() {
        return document;
    }

    public void setDocument(List<String> document) {
        this.document = document;
    }

    public List<String> getAudio() {
        return audio;
    }

    public void setAudio(List<String> audio) {
        this.audio = audio;
    }

    public List<String> getVideo() {
        return video;
    }

    public void setVideo(List<String> video) {
        this.video = video;
    }

    public List<String> getOther() {
        return other;
    }

    public void setOther(List<String> other) {
        this.other = other;
    }

    public List<String> getTable() {
        return table;
    }

    public void setTable(List<String> table) {
        this.table = table;
    }

    public JSONObject getTags() {
        return tags;
    }

    public void setTags(JSONObject tags) {
        this.tags = tags;
    }

    public AddDataTags(List<String> picture, List<String> document, List<String> audio, List<String> video,
                       List<String> other, List<String> table, JSONObject tags) {
        this.picture = picture;
        this.document = document;
        this.audio = audio;
        this.video = video;
        this.other = other;
        this.table = table;
        this.tags = tags;
    }
}


