package com.hikdata.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.hikdata.entities.AddDataTags;
import com.hikdata.entities.CatalogSearch;
import com.hikdata.entities.MuiltiTagSearch;
import com.hikdata.entities.TagCatalog;
import com.hikdata.dao.ESTagAndDataDao;
import com.hikdata.mapper.TagCatalogMapper;
import com.hikdata.service.ESTagAndDataService;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;

@Service
public class ESTagAndDataServiceImpl implements ESTagAndDataService {
    public final static SimpleDateFormat dateFormat_HMS = new SimpleDateFormat("yyyy-MM-dd");

    @Autowired
    ESTagAndDataDao esTagAndDataDao;
    @Autowired
    TagCatalogMapper tagCatalogMapper;

    @Override
    public JSONObject searchByMultiTags(MuiltiTagSearch muiltiTagSearch) {
        SearchResponse searchResult = esTagAndDataDao.searchByMultiTags(muiltiTagSearch);
        JSONObject request = new JSONObject();
        SearchHits hits = searchResult.getHits();
        long countAll = hits.getTotalHits();
        request.put("countAll", countAll);
        JSONArray data = new JSONArray();
        if (hits.getTotalHits() != 0) {
            for (SearchHit hit : hits) {
                JSONObject object = JSON.parseObject(hit.getSourceAsString());
                JSONArray tags = new JSONArray();
                for (String tagField : object.keySet()) {
                    if (tagField.length() == 32 && object.get(tagField) != null) {
                        JSONObject tag = new JSONObject();
                        TagCatalog tagCatalog = tagCatalogMapper.queryDataByUuid(tagField);
                        String secondLevelName = tagCatalog.getChineseName();
                        String firstLeveluuid = tagCatalog.getParentId();
                        String dataType = tagCatalog.getLevelTwoType();
                        TagCatalog tagCatalog1 = tagCatalogMapper.queryDataByUuid(firstLeveluuid);
                        String firstLevelName = tagCatalog1.getChineseName();
                        String tagSystemUuid = tagCatalog1.getParentId();
                        TagCatalog tagCatalog2 = tagCatalogMapper.queryDataByUuid(tagSystemUuid);
                        String systemTagName = tagCatalog2.getChineseName();
                        tag.put("systemTagName", systemTagName);
                        tag.put("firstLevelName", firstLevelName);
                        tag.put("secondLevelName", secondLevelName);
                        JSONArray tagValues = object.getJSONArray(tagField);

                        if (dataType.equals("date")) {
                            Iterator<Object> list = tagValues.iterator();
                            while (list.hasNext()) {
                                Object value = list.next();
                                Date dateTime = new Date((Long) value);
                                tagValues.remove(value);
                                tagValues.add(dateFormat_HMS.format(dateTime));
                            }
                        }
                        tag.put("value", tagValues);
                        tags.add(tag);
                    }
                }
                object.put("tags", tags);
                object.put("type", hit.getIndex());
                object.put("metaID", hit.getId());
                data.add(object);
            }
            request.put("data", data);
        }
        return request;

    }

    @Override
    public Integer addDataTags(AddDataTags addDataTags) {
        Integer addTagsResult = esTagAndDataDao.addDataTags(addDataTags);
        return addTagsResult;
    }

    @Override
    public JSONObject searchByCatelog(CatalogSearch catalogSearch) {
        SearchResponse searchResult = esTagAndDataDao.searchByCatelog(catalogSearch);
        JSONObject request = new JSONObject();
        SearchHits hits = searchResult.getHits();
        long countAll = hits.getTotalHits();
        request.put("countAll", countAll);
        JSONArray data = new JSONArray();
        if (hits.getTotalHits() != 0) {
            for (SearchHit hit : hits) {
                JSONObject object = JSON.parseObject(hit.getSourceAsString());
                JSONArray tags = new JSONArray();
                for (String tagField : object.keySet()) {
                    if (tagField.length() == 32 && object.get(tagField) != null) {
                        JSONObject tag = new JSONObject();
                        TagCatalog tagCatalog = tagCatalogMapper.queryDataByUuid(tagField);
                        String secondLevelName = tagCatalog.getChineseName();
                        String firstLeveluuid = tagCatalog.getParentId();
                        String dataType = tagCatalog.getLevelTwoType();
                        TagCatalog tagCatalog1 = tagCatalogMapper.queryDataByUuid(firstLeveluuid);
                        String firstLevelName = tagCatalog1.getChineseName();
                        String tagSystemUuid = tagCatalog1.getParentId();
                        TagCatalog tagCatalog2 = tagCatalogMapper.queryDataByUuid(tagSystemUuid);
                        String systemTagName = tagCatalog2.getChineseName();
                        tag.put("systemTagName", systemTagName);
                        tag.put("firstLevelName", firstLevelName);
                        tag.put("secondLevelName", secondLevelName);
                        JSONArray tagValues = object.getJSONArray(tagField);
                        if (dataType.equals("date")) {
                            Iterator<Object> list = tagValues.iterator();
                            while (list.hasNext()) {
                                Object value = list.next();
                                Date dateTime = new Date((Long) value);
                                tagValues.remove(value);
                                tagValues.add(dateFormat_HMS.format(dateTime));
                            }
                        }
                        tag.put("value", tagValues);
                        tags.add(tag);
                    }
                }
                object.put("tags", tags);
                object.put("type", hit.getIndex());
                object.put("metaID", hit.getId());
                data.add(object);
            }
            request.put("data", data);
        }
        return request;
    }
}
