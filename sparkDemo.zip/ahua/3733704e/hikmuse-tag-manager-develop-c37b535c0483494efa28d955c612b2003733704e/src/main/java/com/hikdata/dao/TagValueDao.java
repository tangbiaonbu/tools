package com.hikdata.dao;

import com.hikdata.entities.TagValue;

public interface TagValueDao {
    void tagValueUpdate(TagValue tagValue,String oldTag);

    void tagValueDelete(String field, String value, String dataType);
}
