package com.hikdata.service;

import com.hikdata.entities.TagValue;

import java.util.List;

public interface TagValueService {
    Integer tagValueInsert(TagValue tagValue);

    List<TagValue> tagValueQuery(Integer projectId);

    Integer tagValueUpdate(TagValue tagValue);

    Integer tagValueDelete(Integer id);

    List<TagValue> tagValueQueryByUuid(String secondLevelUuid);
}
