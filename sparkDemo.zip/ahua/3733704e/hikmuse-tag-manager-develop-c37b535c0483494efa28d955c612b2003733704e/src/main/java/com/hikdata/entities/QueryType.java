package com.hikdata.entities;

public class QueryType {
    private String levelTwoType;

    public String getLevelTwoType() {
        return levelTwoType;
    }

    public void setLevelTwoType(String levelTwoType) {
        this.levelTwoType = levelTwoType;
    }
}
