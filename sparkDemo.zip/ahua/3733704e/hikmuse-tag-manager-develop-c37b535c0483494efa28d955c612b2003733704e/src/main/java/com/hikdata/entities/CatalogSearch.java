package com.hikdata.entities;

import java.util.List;

public class CatalogSearch {
    private List<String> catalogId;
    private String index;
    private Integer pageSize;
    private Integer pageNum;

    public List<String> getCatalogId() {
        return catalogId;
    }

    public void setCatalogId(List<String> catalogId) {
        this.catalogId = catalogId;
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public CatalogSearch(List<String> catalogId, String index, Integer pageSize, Integer pageNum) {
        this.catalogId = catalogId;
        this.index = index;
        this.pageSize = pageSize;
        this.pageNum = pageNum;
    }

    @Override
    public String toString() {
        return "CatalogSearch{" +
                "catalogId=" + catalogId +
                ", index='" + index + '\'' +
                ", pageSize=" + pageSize +
                ", pageNum=" + pageNum +
                '}';
    }
}
