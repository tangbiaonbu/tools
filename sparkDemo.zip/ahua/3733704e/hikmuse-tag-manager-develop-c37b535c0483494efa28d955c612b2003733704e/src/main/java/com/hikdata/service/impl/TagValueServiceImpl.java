package com.hikdata.service.impl;

import com.hikdata.dao.TagValueDao;
import com.hikdata.entities.TagValue;
import com.hikdata.mapper.TagValueMapper;
import com.hikdata.service.TagValueService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Repository
public class TagValueServiceImpl implements TagValueService {
    private Logger logger = LoggerFactory.getLogger(getClass());
    @Autowired
    TagValueMapper tagValueMapper;

    @Autowired
    TagValueDao tagValueDao;

    @Override
    public Integer tagValueInsert(TagValue tagValue) {
        String tagValueValidate = tagValue.getTagValue();
        List<TagValue> validResult = tagValueMapper.tagValueValid(tagValueValidate);
        if (validResult.isEmpty()) {
            int insertMysqlResult = tagValueMapper.tagValueInsert(tagValue);
            logger.info("tags insert mysql or DM status : {}",insertMysqlResult);
            return insertMysqlResult;
        } else {
            return -1;
        }
    }

    @Override
    public List<TagValue> tagValueQuery(Integer projectId) {

        return tagValueMapper.tagValueQuery(projectId);
    }

    @Override
    public Integer tagValueUpdate(TagValue tagValue) {
        //校验修改值是否有重名的情况
        String tagValueValidate = tagValue.getTagValue();
        List<TagValue> validResult = tagValueMapper.tagValueValid(tagValueValidate);
        if (validResult.isEmpty()) {
            String oldTag = tagValueMapper.queryOldTagValueById(tagValue.getId()).getTagValue();
            //修改es中对应数据的标签值
            tagValueDao.tagValueUpdate(tagValue,oldTag);
            int updateStatus = tagValueMapper.tagValueUpdate(tagValue);
            logger.info("tags value update value  : {}", updateStatus);
            return updateStatus;
        } else {
            return 0;
        }
    }

    @Override
    public Integer tagValueDelete(Integer id) {
        TagValue tagValue = tagValueMapper.queryOldTagValueById(id);
        String dataType = tagValue.getDataType();
        String value = tagValue.getTagValue();
        String field = tagValue.getSecondLevelUuid();
        tagValueDao.tagValueDelete(field,value,dataType);
        return tagValueMapper.tagValueDelete(id);
    }

    @Override
    public List<TagValue> tagValueQueryByUuid(String secondLevelUuid) {
        return tagValueMapper.tagValueQueryByUuid(secondLevelUuid);
    }
}
