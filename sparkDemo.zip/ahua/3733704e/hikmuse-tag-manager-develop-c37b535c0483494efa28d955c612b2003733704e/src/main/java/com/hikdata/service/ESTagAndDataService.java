package com.hikdata.service;

import com.alibaba.fastjson.JSONObject;
import com.hikdata.entities.AddDataTags;
import com.hikdata.entities.CatalogSearch;
import com.hikdata.entities.MuiltiTagSearch;

public interface ESTagAndDataService {
    JSONObject searchByMultiTags(MuiltiTagSearch muiltiTagSearch);

    Integer addDataTags(AddDataTags addDataTags);

    JSONObject searchByCatelog(CatalogSearch catalogSearch);
}
