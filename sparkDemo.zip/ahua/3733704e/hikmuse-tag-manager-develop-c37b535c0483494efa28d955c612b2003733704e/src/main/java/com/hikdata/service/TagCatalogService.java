package com.hikdata.service;

import com.alibaba.fastjson.JSONArray;
import com.hikdata.entities.TagCatalog;

import java.util.List;

public interface TagCatalogService {
    
    Integer tagInsert(TagCatalog tagCatalog);

    JSONArray tagCatalogQuery(Integer projectId);

    Integer tagCatalogUpdate(TagCatalog tagCatalog);

    String tagCatalogDelete(String uuid);

    List<TagCatalog> systemTagQuery();

    List<TagCatalog> nextLevelQuery(String uuid);
}
