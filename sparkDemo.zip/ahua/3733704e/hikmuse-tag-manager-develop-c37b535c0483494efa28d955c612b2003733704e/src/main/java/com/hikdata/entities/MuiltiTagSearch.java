package com.hikdata.entities;

import com.alibaba.fastjson.JSONObject;

public class MuiltiTagSearch {
    private JSONObject muiltiTags;
    private String index;
    private Integer pageSize;
    private Integer pageNum;
    private String searchKeyWord;
    private Long gt;
    private Long lt;

    public Long getGt() {
        return gt;
    }

    public void setGt(Long gt) {
        this.gt = gt;
    }

    public Long getLt() {
        return lt;
    }

    public void setLt(Long lt) {
        this.lt = lt;
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public JSONObject getMuiltiTags() {
        return muiltiTags;
    }

    public void setMuiltiTags(JSONObject muiltiTags) {
        this.muiltiTags = muiltiTags;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public String getSearchKeyWord() {
        return searchKeyWord;
    }

    public void setSearchKeyWord(String searchKeyWord) {
        this.searchKeyWord = searchKeyWord;
    }
}
