package com.hikdata.utils;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class FileUtil {
    public void FileUtils() {
    }

    public static String file2json(File file) {
        if (!file.exists()) {
            return "{}";
        } else {
            try {
                InputStream in = new FileInputStream(file);
                BufferedReader br = new BufferedReader(new InputStreamReader(in));
                StringBuilder builder = new StringBuilder();

                String line;
                while ((line = br.readLine()) != null) {
                    System.out.println(line);
                    builder.append(line);
                }

                return builder.toString();
            } catch (FileNotFoundException var5) {
                var5.printStackTrace();
                return "{}";
            } catch (IOException var6) {
                return "{}";
            }
        }
    }

    public static String stream2json(InputStream in) throws IOException {
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            StringBuilder builder = new StringBuilder();

            String line;
            while ((line = br.readLine()) != null) {
                System.out.println(line);
                builder.append(line);
            }

            return builder.toString();
        } catch (FileNotFoundException var4) {
            var4.printStackTrace();
            return null;
        } catch (IOException var5) {
            throw var5;
        }
    }

    public static void saveImageByBase64(String path, byte[] img) throws IOException {
        FileOutputStream outputStream = new FileOutputStream(path);
        outputStream.write(img);
        outputStream.flush();
        outputStream.close();
    }

    public static byte[] file2byte(File file) {
        byte[] bytes = null;
        FileInputStream in = null;
        ByteArrayOutputStream bos = null;

        try {
            in = new FileInputStream(file);
            bos = new ByteArrayOutputStream(1000);
            byte[] b = new byte[1000];

            int n;
            while ((n = in.read(b)) != -1) {
                bos.write(b, 0, n);
            }

            bytes = bos.toByteArray();
        } catch (IOException var18) {
            var18.printStackTrace();
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException var17) {
                    var17.printStackTrace();
                }
            }

            if (bos != null) {
                try {
                    bos.close();
                } catch (IOException var16) {
                    var16.printStackTrace();
                }
            }
        }

        return bytes;
    }
}
