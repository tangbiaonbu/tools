package com.hikdata.dao.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.hikdata.TagManagerServer;
import com.hikdata.dao.TagValueDao;
import com.hikdata.entities.TagValue;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.client.Client;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

@Repository
public class TagValueDaoImpl implements TagValueDao {
    private Logger logger = LoggerFactory.getLogger(getClass());

    private final static String VIDEO_META_INDEX = "video_metadata";
    private final static String AUDIO_META_INDEX = "audio_metadata";
    private final static String PICTURE_META_INDEX = "picture_metadata";
    private final static String DOCUMENT_META_INDEX = "document_metadata";
    private final static String OTHER_META_INDEX = "other_metadata";
    private final static String TABLE_META_INDEX = "table_metadata";
    private final static String METALIB_TYPE = "info";

    @Override
    public void tagValueUpdate(TagValue tagValue, String oldTag) {
        //修改uuid:[oldValue，value,...] ->uuid:[newValue，value,...]
        Client client = TagManagerServer.getClient();
        String field = tagValue.getSecondLevelUuid();
        String newTagValue = tagValue.getTagValue();
        SearchResponse searchResponse =
                client.prepareSearch(new String[]{VIDEO_META_INDEX,
                        AUDIO_META_INDEX,
                        PICTURE_META_INDEX, DOCUMENT_META_INDEX, OTHER_META_INDEX, TABLE_META_INDEX}).
                        setTypes(new String[]{METALIB_TYPE, METALIB_TYPE, METALIB_TYPE, METALIB_TYPE, METALIB_TYPE,
                                METALIB_TYPE}).setQuery(QueryBuilders.matchPhraseQuery(field, oldTag)).get();
        SearchHits hits = searchResponse.getHits();
        UpdateRequest updateRequest = new UpdateRequest();
        if (hits.getTotalHits() != 0) {
            for (SearchHit hit : hits) {
                JSONObject object = JSON.parseObject(hit.getSourceAsString());
                JSONArray newFieldValue = object.getJSONArray(field);
                newFieldValue.remove(oldTag);
                newFieldValue.add(newTagValue);
                object.replace(field, newFieldValue);
                String metaId = hit.getId();
                String index = hit.getIndex();
                updateRequest.index(index).type(METALIB_TYPE).id(metaId).doc(object);
                client.update(updateRequest);
            }
            client.close();
        }
    }

    @Override
    public void tagValueDelete(String field, String value, String dataType) {
        Client client = TagManagerServer.getClient();
        MatchQueryBuilder matchQueryBuilder = null;
        if (dataType.equals("vachar")) {
            matchQueryBuilder = QueryBuilders.matchQuery(field, value);
        } else if (dataType.equals("number")) {
            boolean int_flag = value.matches("^(\\-|\\+)?\\d*$");
            if (int_flag) {
                matchQueryBuilder = QueryBuilders.matchQuery(field, Integer.parseInt(value));
            } else {
                matchQueryBuilder = QueryBuilders.matchQuery(field, Float.parseFloat(value));
            }
        } else if (dataType.equals("date")) {
            matchQueryBuilder = QueryBuilders.matchQuery(field, Long.parseLong(value));
        }
        SearchResponse searchResponse = client.prepareSearch(new String[]{VIDEO_META_INDEX,
                AUDIO_META_INDEX,
                PICTURE_META_INDEX, DOCUMENT_META_INDEX, OTHER_META_INDEX, TABLE_META_INDEX}).
                setTypes(new String[]{METALIB_TYPE, METALIB_TYPE, METALIB_TYPE, METALIB_TYPE, METALIB_TYPE,
                        METALIB_TYPE}).setQuery(matchQueryBuilder).get();

        SearchHits hits = searchResponse.getHits();
        BulkRequest bulkRequest = new BulkRequest();
        if (hits.getTotalHits() != 0) {
            for (SearchHit hit : hits) {
                JSONObject object = JSON.parseObject(hit.getSourceAsString());
                JSONArray newFieldValue = object.getJSONArray(field);
                if (dataType.equals("number")) {
                    boolean int_flag = value.matches("^(\\-|\\+)?\\d*$");
                    if (int_flag) {
                        int index = newFieldValue.indexOf(Integer.parseInt(value));
                        if (index != -1) {
                            newFieldValue.remove(index);
                        }
                    } else {
                        int index = newFieldValue.indexOf(Float.parseFloat(value));
                        if (index != -1) {
                            newFieldValue.remove(index);
                        }
                    }
                } else if (dataType.equals("date")) {
                    int index = newFieldValue.indexOf(Long.parseLong(value));
                    if (index != -1) {
                        newFieldValue.remove(index);
                    }
                } else {
                    newFieldValue.remove(value);
                }
                object.replace(field, newFieldValue);
                String metaId = hit.getId();
                String index = hit.getIndex();
                UpdateRequest updateRequest = new UpdateRequest();
                updateRequest.index(index).type(METALIB_TYPE).id(metaId).doc(object);
                bulkRequest.add(updateRequest);
            }
            client.bulk(bulkRequest);
            client.close();
        }
    }
}
