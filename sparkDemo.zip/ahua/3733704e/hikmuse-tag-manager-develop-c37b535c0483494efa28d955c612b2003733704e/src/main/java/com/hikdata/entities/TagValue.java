package com.hikdata.entities;

public class TagValue {
    private Integer id;
    private String secondLevelUuid;
    private String tagValue;
    private String dataType;
    private Integer projectId;

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTagValue() {
        return tagValue;
    }

    public void setTagValue(String tagValue) {
        this.tagValue = tagValue;
    }

    public String getSecondLevelUuid() {
        return secondLevelUuid;
    }

    public void setSecondLevelUuid(String secondLevelUuid) {
        this.secondLevelUuid = secondLevelUuid;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }
}


