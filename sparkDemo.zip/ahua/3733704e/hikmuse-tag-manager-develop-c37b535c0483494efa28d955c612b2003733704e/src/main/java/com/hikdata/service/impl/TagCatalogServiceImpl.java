package com.hikdata.service.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.hikdata.dao.TagCatalogDao;
import com.hikdata.entities.QueryUuid;
import com.hikdata.entities.TagCatalog;
import com.hikdata.mapper.TagCatalogMapper;
import com.hikdata.mapper.TagValueMapper;
import com.hikdata.service.TagCatalogService;
import com.hikdata.utils.UuidUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TagCatalogServiceImpl implements TagCatalogService {
    private Logger logger = LoggerFactory.getLogger(TagCatalogServiceImpl.class);

    @Autowired
    TagCatalogMapper tagCatalogMapper;

    @Autowired
    TagValueMapper tagValueMapper;

    @Autowired
    TagCatalogDao tagCatalogDao;

    @Override
    public Integer tagInsert(TagCatalog tagCatalog) {
        //校验是否重名
        String chineseNameValid = tagCatalog.getChineseName();
        List<TagCatalog> validResult = tagCatalogMapper.tagCatalogValid(chineseNameValid);
        if (validResult.isEmpty()) {
            tagCatalog.setUuid(UuidUtil.getUUID32());
            return tagCatalogMapper.tagInsert(tagCatalog);
        } else {
            return 0;
        }
    }

    @Override
    public JSONArray tagCatalogQuery(Integer projectId) {
        List<TagCatalog> queryResult = tagCatalogMapper.tagCatalogQuery(projectId);
        JSONArray result = new JSONArray();
        if (queryResult.size() != 0) {
            for (TagCatalog next : queryResult) {
                if (next.getLevelId() == 1) {
                    JSONObject first = new JSONObject();
                    String uuid1 = next.getUuid();
                    first.put("levelId", next.getLevelId());
                    first.put("ParentId", next.getParentId());
                    first.put("uuid", uuid1);
                    first.put("chineseName", next.getChineseName());
                    first.put("englishName", next.getEnglishName());
                    first.put("id", next.getId());
                    first.put("levelTwoType", next.getLevelTwoType());
                    first.put("projectId", next.getProjectId());
                    first.put("sortField", next.getSortField());
                    first.put("introduction", next.getIntroduction());
                    JSONArray firstArray = new JSONArray();
                    for (TagCatalog tagFirstSon : queryResult) {
                        if (tagFirstSon.getLevelId() == 2 && tagFirstSon.getParentId().equals(uuid1)) {
                            JSONObject second = new JSONObject();
                            String uuid2 = tagFirstSon.getUuid();
                            second.put("levelId", tagFirstSon.getLevelId());
                            second.put("ParentId", tagFirstSon.getParentId());
                            second.put("uuid", uuid2);
                            second.put("chineseName", tagFirstSon.getChineseName());
                            second.put("englishName", tagFirstSon.getEnglishName());
                            second.put("id", tagFirstSon.getId());
                            second.put("levelTwoType", tagFirstSon.getLevelTwoType());
                            second.put("projectId", tagFirstSon.getProjectId());
                            second.put("sortField", tagFirstSon.getSortField());
                            second.put("introduction", tagFirstSon.getIntroduction());
                            JSONArray secondArray = new JSONArray();
                            for (TagCatalog tagsecondSon : queryResult) {
                                if (tagsecondSon.getLevelId() == 3 && tagsecondSon.getParentId().equals(uuid2)) {
                                    JSONObject third = new JSONObject();
                                    String uuid3 = tagsecondSon.getUuid();
                                    third.put("levelId", tagsecondSon.getLevelId());
                                    third.put("ParentId", tagsecondSon.getParentId());
                                    third.put("uuid", uuid3);
                                    third.put("chineseName", tagsecondSon.getChineseName());
                                    third.put("englishName", tagsecondSon.getEnglishName());
                                    third.put("id", tagsecondSon.getId());
                                    third.put("levelTwoType", tagsecondSon.getLevelTwoType());
                                    third.put("projectId", tagsecondSon.getProjectId());
                                    third.put("sortField", tagsecondSon.getSortField());
                                    third.put("introduction", tagsecondSon.getIntroduction());
                                    secondArray.add(third);
                                }
                                second.put("secondLevel", secondArray);
                            }
                            firstArray.add(second);
                        }
                        first.put("firstLevel", firstArray);
                    }
                    result.add(first);
                }
            }
        }
        return result;
    }

    @Override
    public Integer tagCatalogUpdate(TagCatalog tagCatalog) {
        String chineseNameValid = tagCatalog.getChineseName();
        String uuid = tagCatalog.getUuid();
        String oldDataName = tagCatalogMapper.queryChineseNameByUuid(uuid);
        if (oldDataName.equals(chineseNameValid)) {
            if (tagCatalog.getLevelTwoType() != null) {
                String oldType = tagCatalogMapper.queryTypeByUuid(uuid).getLevelTwoType();
                if (!tagCatalog.getLevelTwoType().equals(oldType)) {
                    tagCatalog.setUuid(UuidUtil.getUUID32());
                }
            }
            return tagCatalogMapper.tagCatalogUpdate(tagCatalog);
        } else {
            List<TagCatalog> validResult = tagCatalogMapper.tagCatalogValid(chineseNameValid);
            if (validResult.isEmpty()) {
                //todo 测试 如果该二级标签的type变了  则修改该值的UUid（请不要随意修改标签值的类型，修改了会清空原有的标签值）
                if (tagCatalog.getLevelTwoType() != null) {
                    String oldType = tagCatalogMapper.queryTypeByUuid(uuid).getLevelTwoType();
                    if (!tagCatalog.getLevelTwoType().equals(oldType)) {
                        tagCatalog.setUuid(UuidUtil.getUUID32());
                    }
                }
                return tagCatalogMapper.tagCatalogUpdate(tagCatalog);
            } else {
                return 0;
            }
        }
    }

    @Override
    public String tagCatalogDelete(String uuid) {
        int secondCount = 0, thirdCount = 0;
        tagCatalogMapper.tagCatalogDelete(uuid);
        int tagValueDeleteStatus = tagValueMapper.catalogAndTagValueDelete(uuid);
        tagCatalogDao.deleteTagOndata(uuid);
        logger.info("第一层标签值删除情况{}", tagValueDeleteStatus);
        List<QueryUuid> uuidList1 = tagCatalogMapper.queryParentIdEqualsUuid(uuid);
        if (!uuidList1.isEmpty()) {
            for (QueryUuid uuidSon : uuidList1) {
                secondCount += tagCatalogMapper.tagCatalogDelete(uuidSon.getUuid());
                int tagValueDeleteStatus2 = tagValueMapper.catalogAndTagValueDelete(uuidSon.getUuid());
                tagCatalogDao.deleteTagOndata(uuidSon.getUuid());
                logger.info("第二层标签值删除情况{}", tagValueDeleteStatus2);
                List<QueryUuid> uuidList2 = tagCatalogMapper.queryParentIdEqualsUuid(uuidSon.getUuid());
                if (!uuidList2.isEmpty()) {
                    for (QueryUuid uuidSonSon : uuidList2) {
                        thirdCount += tagCatalogMapper.tagCatalogDelete(uuidSonSon.getUuid());
                        int tagValueDeleteStatus3 = tagValueMapper.catalogAndTagValueDelete(uuidSonSon.getUuid());
                        tagCatalogDao.deleteTagOndata(uuidSonSon.getUuid());
                        logger.info("第三层标签值删除情况{}", tagValueDeleteStatus3);
                    }
                    return "成功删除此条标签，下级标签" + secondCount + "条" + ", 下下级标签" + thirdCount + "条";
                }
            }
            return "成功删除此条标签，且下级标签" + secondCount + "条";
        }
        {
            return "成功删除此条标签";
        }
    }

    @Override
    public List<TagCatalog> systemTagQuery() {
        return tagCatalogMapper.systemTagQuery();
    }

    @Override
    public List<TagCatalog> nextLevelQuery(String uuid) {
        return tagCatalogMapper.nextLevelQuery(uuid);
    }
}
