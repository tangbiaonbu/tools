package com.hikdata.controller;

import com.hikdata.entities.TagValue;
import com.hikdata.entities.dto.ResultVO;
import com.hikdata.service.TagValueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

@RestController
public class TagValueController {
    @Autowired
    TagValueService tagValueService;

    /**
     * 给某个二级标签插入值
     *
     * @param tagValue
     * @return
     */
    @PostMapping("/tagvalue/insert")
    public ResultVO tagValueInsert(@RequestBody @Valid @NotNull(message = "参数不能为空") TagValue tagValue) {
        Integer insertResult = tagValueService.tagValueInsert(tagValue);
        if (insertResult == 1) {
            return ResultVO.isOk(insertResult);
        } else {
            return ResultVO.isOk("此标签已存在");
        }
    }

    /**
     * 获取所有的二级标签值
     *
     * @return
     */
    @GetMapping("/tagvalue/querybyproject/{projectId}")
    public ResultVO tagValueQuery(@NotNull @PathVariable(name = "projectId") Integer projectId) {
        List<TagValue> queryResult = tagValueService.tagValueQuery(projectId);
        return ResultVO.isOk(queryResult);
    }

    /**
     * 获取某个二级标签下的的具体标签值
     *
     * @return
     */
    @GetMapping("/tagvalue/query/{secondLevelUuid}")
    public ResultVO tagValueQueryByUuid(@NotNull @PathVariable(name = "secondLevelUuid") String secondLevelUuid) {
        List<TagValue> queryResult = tagValueService.tagValueQueryByUuid(secondLevelUuid);
        return ResultVO.isOk(queryResult);
    }

    /**
     * 修改二级标签的值
     *
     * @param tagValue
     * @return
     */
    @PostMapping("/tagvalue/update")
    public ResultVO tagValueUpdate(@RequestBody @Valid @NotNull(message = "参数不能为空") TagValue tagValue) {
        Integer updateResult = tagValueService.tagValueUpdate(tagValue);
        if (updateResult == 1) {
            return ResultVO.isOk(updateResult);
        } else {
            return ResultVO.isOk("此标签值已存在");
        }
    }

    /**
     * 删除具体的标签值
     *
     * @param id
     * @return
     */
    @DeleteMapping("/tagvalue/delete/{id}")
    public ResultVO tagValueDelete(@NotNull @PathVariable(name = "id") Integer id) {
        Integer deleteResult = tagValueService.tagValueDelete(id);
        return ResultVO.isOk(deleteResult);
    }
    
}
