package com.hikdata.controller;

import com.alibaba.fastjson.JSONArray;
import com.hikdata.entities.TagCatalog;
import com.hikdata.entities.dto.ResultVO;
import com.hikdata.service.TagCatalogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;


@RestController
public class TagCatalogController {
    @Autowired
    TagCatalogService tagCatalogService;

    /**
     * 创建标签体系、一级标签、二级标签
     * @param tagCatalog
     * @return
     */
    @PostMapping("/tagcatalog/insert")
    public ResultVO tagInsert(@RequestBody @Valid @NotNull(message = "参数不能为空") TagCatalog tagCatalog) {
        Integer insertResult = tagCatalogService.tagInsert(tagCatalog);
        if (insertResult == 1) {
            return ResultVO.isOk(insertResult);
        } else {
            ResultVO resultVO = new ResultVO();
            resultVO.setMsg("存在重复标签值");
            resultVO.setStatus(200);
            return resultVO;
        }
    }

    /**
     * 获取标签目录结构
     * @return
     */
    @GetMapping("/tagcatalog/query/{projectid}")
    public ResultVO tagCatalogQuery(@PathVariable(name = "projectid") Integer projectId) {
        JSONArray queryResult = tagCatalogService.tagCatalogQuery(projectId);
        return ResultVO.isOk(queryResult);
    }

    /**
     * 更新标签体系、一级标签、二级标签
     * @param tagCatalog
     * @return
     */
    @PostMapping("/tagcatalog/update")
    public ResultVO tagCatalogUpdate(@RequestBody @Valid @NotNull(message = "参数不能为空") TagCatalog tagCatalog) {
        Integer updateResult = tagCatalogService.tagCatalogUpdate(tagCatalog);
        if (updateResult == 1) {
            return ResultVO.isOk(updateResult);
        } else {
            ResultVO resultVO = new ResultVO();
            resultVO.setMsg("存在重复标签值");
            resultVO.setStatus(200);
            return resultVO;
        }
    }

    /**
     * 删除标签信息
     * @param uuid 标签唯一标识
     * @return
     */
    @DeleteMapping("/tagcatalog/delete/{uuid}")
    public ResultVO tagCatalogDelete(@NotNull @PathVariable(name = "uuid") String uuid) {
        String deleteResult = tagCatalogService.tagCatalogDelete(uuid);
        return ResultVO.isOk(deleteResult);
    }

    /**
     * 获取标签体系接口
     * @return
     */
    @GetMapping("/tagcatalog/systemtag")
    public ResultVO systemTagQuery() {
        List<TagCatalog> queryResult = tagCatalogService.systemTagQuery();
        return ResultVO.isOk(queryResult);
    }

    /**
     * 通过标签体系获取下面的一级标签，通过一级标签获取二级标签
     * @param uuid
     * @return
     */
    @GetMapping("/tagcatalog/nextlevel/{uuid}")
    public ResultVO nextlevelQuery(@NotNull @PathVariable(name = "uuid") String uuid) {
        List<TagCatalog> queryResult = tagCatalogService.nextLevelQuery(uuid);
        return ResultVO.isOk(queryResult);
    }
}
