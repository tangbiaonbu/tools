package com.hikdata.dao;

import com.alibaba.fastjson.JSONObject;
import com.hikdata.entities.AddDataTags;
import com.hikdata.entities.CatalogSearch;
import com.hikdata.entities.MuiltiTagSearch;
import org.elasticsearch.action.search.SearchResponse;

public interface ESTagAndDataDao {
    SearchResponse searchByMultiTags(MuiltiTagSearch muiltiTagSearch);

    Integer addDataTags(AddDataTags addDataTags);

    SearchResponse searchByCatelog(CatalogSearch catalogSearch);
}
