package com.hikdata.dao.impl;

import com.hikdata.TagManagerServer;
import com.hikdata.dao.TagCatalogDao;
import org.elasticsearch.client.Client;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.reindex.UpdateByQueryAction;
import org.elasticsearch.index.reindex.UpdateByQueryRequestBuilder;
import org.elasticsearch.script.Script;
import org.elasticsearch.script.ScriptType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.util.Collections;

@Repository
public class TagCatalogDaoImpl implements TagCatalogDao {

    private Logger logger = LoggerFactory.getLogger(TagCatalogDaoImpl.class);

    private final static String VIDEO_META_INDEX = "video_metadata";
    private final static String AUDIO_META_INDEX = "audio_metadata";
    private final static String PICTURE_META_INDEX = "picture_metadata";
    private final static String DOCUMENT_META_INDEX = "document_metadata";
    private final static String OTHER_META_INDEX = "other_metadata";
    private final static String TABLE_META_INDEX = "table_metadata";

    @Override
    public void deleteTagOndata(String uuid) {
        Client client = TagManagerServer.getClient();
        UpdateByQueryRequestBuilder updateByQuery = UpdateByQueryAction.INSTANCE.newRequestBuilder(client);
        updateByQuery.source(new String[]{VIDEO_META_INDEX, AUDIO_META_INDEX, PICTURE_META_INDEX, DOCUMENT_META_INDEX
                , OTHER_META_INDEX, TABLE_META_INDEX}).filter(QueryBuilders.existsQuery(uuid)).
                script(new Script(
                        ScriptType.INLINE, "painless", "ctx" + "._source.remove(" + "'" + uuid + "'" + ")" + ";",
                        Collections.emptyMap()));
        int successUpdate = 0;
        successUpdate += updateByQuery.get().getUpdated();
        logger.info("uuid为{},更新状态为{}", uuid, successUpdate);
        System.out.println(successUpdate + uuid);
        client.close();
    }
}
