package com.hikdata.controller;

import com.alibaba.fastjson.JSONObject;
import com.hikdata.entities.AddDataTags;
import com.hikdata.entities.CatalogSearch;
import com.hikdata.entities.MuiltiTagSearch;
import com.hikdata.entities.dto.ResultVO;
import com.hikdata.service.ESTagAndDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@RestController
public class ESTagAndDataController {

    @Autowired
    ESTagAndDataService esTagAndDataService;

    @PostMapping("/multiltagssearch")
    public ResultVO searchByMultiTags(@RequestBody @Valid @NotNull(message = "参数不能为空") MuiltiTagSearch muiltiTagSearch) {
        JSONObject result = esTagAndDataService.searchByMultiTags(muiltiTagSearch);
        return ResultVO.isOk(result);
    }

    @PostMapping("/adddatatags")
    public ResultVO addDataTags(@RequestBody @Valid @NotNull(message = "参数不能为空") AddDataTags addDataTags) {
        Integer addResult = esTagAndDataService.addDataTags(addDataTags);
        return ResultVO.isOk(addResult);
    }

    @PostMapping("/catalogsearch")
    public ResultVO searchByCatelog(@RequestBody @Valid @NotNull(message = "参数不能为空") CatalogSearch catalogSearch) {
        JSONObject result = esTagAndDataService.searchByCatelog(catalogSearch);
        return ResultVO.isOk(result);
    }
    
}
