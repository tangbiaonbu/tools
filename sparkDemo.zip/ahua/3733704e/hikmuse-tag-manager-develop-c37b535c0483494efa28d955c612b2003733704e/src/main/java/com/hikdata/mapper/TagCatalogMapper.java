package com.hikdata.mapper;

import com.hikdata.entities.QueryType;
import com.hikdata.entities.QueryUuid;
import com.hikdata.entities.TagCatalog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface TagCatalogMapper {
    
    List<TagCatalog> tagCatalogValid(@Param("chineseName") String chineseName);

    Integer tagInsert(@Param("tagCatalog") TagCatalog tagCatalog);

    List<TagCatalog> tagCatalogQuery(@Param("projectId") Integer projectId);

    Integer tagCatalogUpdate(@Param("tagCatalog") TagCatalog tagCatalog);

    Integer tagCatalogDelete(@Param("uuid") String uuid);

    List<QueryUuid> queryParentIdEqualsUuid(@Param("uuid") String uuid);

    List<TagCatalog> systemTagQuery();

    //校验
    List<TagCatalog> nextLevelQuery(@Param("uuid") String uuid);

    QueryType queryTypeByUuid (@Param("uuid") String uuid);

    String queryChineseNameByUuid(@Param("uuid") String uuid);
    
    TagCatalog queryDataByUuid(@Param("uuid") String uuid);
}
