package com.hikdata.dao;

public interface TagCatalogDao {
    void deleteTagOndata(String uuid);
}
