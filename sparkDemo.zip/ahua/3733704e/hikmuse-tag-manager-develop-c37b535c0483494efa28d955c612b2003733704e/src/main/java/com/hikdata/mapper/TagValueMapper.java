package com.hikdata.mapper;

import com.hikdata.entities.TagValue;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface TagValueMapper {
    List<TagValue> tagValueValid(@Param("tagValue") String tagValue);
    
    Integer tagValueInsert(@Param("tagValue") TagValue tagValue);

    List<TagValue> tagValueQuery(@Param("projectId") Integer projectId);

    Integer tagValueUpdate(@Param("tagValue") TagValue tagValue);

    Integer tagValueDelete(@Param("id") Integer id);

    /**
     * 删除标签体系、一级标签、二级标签时 把对应的标签值删掉
     * @param secondLevelUuid
     * @return
     */
    Integer catalogAndTagValueDelete(@Param("secondLevelUuid") String secondLevelUuid);

    List<TagValue> tagValueQueryByUuid(@Param("secondLevelUuid") String secondLevelUuid);

    TagValue queryOldTagValueById(@Param("id") Integer id);
}
