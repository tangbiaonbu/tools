package com.hikdata;

import com.hikdata.config.TagManageSettings;
import com.hikdata.utils.SpringUtil;
import org.elasticsearch.client.Client;
import org.elasticsearch.client.transport.NoNodeAvailableException;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.xpack.client.PreBuiltXPackTransportClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.lang.reflect.Proxy;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;

@SpringBootApplication
//@EnableTransactionManagement
//@EnableScheduling
//@EnableAsync
public class TagManagerServer {
    private final static Logger logger = LoggerFactory.getLogger(TagManagerServer.class);
    private static List<Client> pool = new ArrayList<Client>();

    public static ThreadPoolExecutor impOrExpTaskThread;

    public static void main(String[] args) throws Exception {
        SpringApplication.run(TagManagerServer.class, args);
//        impOrExpTaskThread = new ThreadPoolExecutor(5, 10, 0,
//                TimeUnit.MILLISECONDS, new ArrayBlockingQueue<Runnable>(1024));
        TagManagerServer.createClientPool();
        logger.info("启动成功");
    }

    /**
     * 创建数据库连接池
     */
    public static void createClientPool() {
        TagManageSettings tagManageSettings = SpringUtil.getBean(TagManageSettings.class);
        try {
            Settings.builder().put("cluster.name", tagManageSettings.clusterName)
                    .put("client.transport.sniff", false)
                    .build();
            for (int i = 0; i < tagManageSettings.size; i++) {
                final TransportClient client = new PreBuiltXPackTransportClient(Settings.builder()
                        .put("cluster.name", tagManageSettings.clusterName)
                        .put("xpack.security.user", tagManageSettings.password)
                        .build())
                        .addTransportAddress(
                                new InetSocketTransportAddress(InetAddress.getByName(tagManageSettings.host),
                                        tagManageSettings.port));
                Client cli = (Client) Proxy.newProxyInstance(TagManageSettings.class.getClassLoader(),
                        new Class[]{Client.class},
                        (proxy, method, args) -> {
                            if ("close".equalsIgnoreCase(method.getName())) {
                                pool.add((Client) proxy);
                                return null;
                            }
                            return method.invoke(client, args);
                        });

                try {
//                    client.admin().indices().exists(new IndicesExistsRequest().actionGet();
                } catch (NoNodeAvailableException e) {
                    logger.error(String.format("Failed to init es client %s, reason: %s.", i, e.getMessage()));
                    continue;
                } catch (Exception e) {
                    logger.error(String.format("Failed to init es client %s, reason: %s.", i, e.getMessage()));
                    continue;
                }
                pool.add(cli);
                logger.info("pool size: " + pool.size());
            }
        } catch (Exception e) {
            logger.error("Failed to create Elasticsearch clients :  " + e.getMessage());
            System.exit(1);
        }
    }

    /**
     * 获取客户端连接池
     **/
    public static synchronized Client getClient() {
        if (pool.size() < 1) {
            try {
                Thread.sleep(100);
                return getClient();
            } catch (InterruptedException e) {
            }
        }
        return pool.remove(0);
    }

}
