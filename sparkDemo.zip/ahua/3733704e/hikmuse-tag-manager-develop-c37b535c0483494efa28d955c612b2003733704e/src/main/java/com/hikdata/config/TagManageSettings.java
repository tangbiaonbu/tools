package com.hikdata.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
//@PropertySource("classpath:applicationmysql.properties")
//@PropertySource("classpath:applicationdm.properties")
//@PropertySource("classpath:applicationpostgre.properties")
@PropertySource("file:${spring.profile.path}")
public class TagManageSettings {
    @Value("${spring.datasource.elasticsearch.hosts}")
    public String host;

    @Value("${spring.datasource.elasticsearch.tcpPort}")
    public int port;

    @Value("${spring.datasource.elasticsearch.clusterName}")
    public String clusterName;

    @Value("${spring.datasource.elasticsearch.password}")
    public String password;

    @Value("${spring.datasource.elasticsearch.poolSize}")
    public int size;

    public TagManageSettings(){}

    public TagManageSettings(String host, int port, String clusterName, String password, int size) {
        this.host = host;
        this.port = port;
        this.clusterName = clusterName;
        this.password = password;
        this.size = size;
    }

    @Override
    public String toString() {
        return "TagManageSettings{" +
                "host='" + host + '\'' +
                ", port=" + port +
                ", clusterName='" + clusterName + '\'' +
                ", password='" + password + '\'' +
                ", size=" + size +
                '}';
    }
}
