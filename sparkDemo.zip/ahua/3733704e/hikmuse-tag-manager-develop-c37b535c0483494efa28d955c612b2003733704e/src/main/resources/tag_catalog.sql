/*
Navicat PGSQL Data Transfer

Source Server         : 70pre
Source Server Version : 90214
Source Host           : 10.0.3.70:5432
Source Database       : hikmuse
Source Schema         : public

Target Server Type    : PGSQL
Target Server Version : 90214
File Encoding         : 65001

Date: 2021-04-12 16:14:16
*/


-- ----------------------------
-- Table structure for tag_catalog
-- ----------------------------
DROP TABLE IF EXISTS "public"."tag_catalog";
CREATE TABLE "public"."tag_catalog" (
"id" bigserial NOT NULL,
"level_id" int4 NOT NULL,
"chinese_name" varchar(255) COLLATE "default" DEFAULT NULL::character varying NOT NULL,
"english_name" varchar(255) COLLATE "default" DEFAULT NULL::character varying NOT NULL,
"parent_id" varchar(255) COLLATE "default" DEFAULT NULL::character varying NOT NULL,
"uuid" varchar(255) COLLATE "default" DEFAULT NULL::character varying NOT NULL,
"introduction" varchar(255) COLLATE "default" DEFAULT NULL::character varying NOT NULL,
"sort_field" int4,
"project_id" int4 NOT NULL,
"level_two_type" varchar(255) COLLATE "default",
CONSTRAINT tag_catalog_pkey PRIMARY KEY (id)

)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Alter Sequences Owned By 
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table tag_catalog
-- ----------------------------
GRANT ALL ON TABLE public.tag_catalog TO hikmuse;


