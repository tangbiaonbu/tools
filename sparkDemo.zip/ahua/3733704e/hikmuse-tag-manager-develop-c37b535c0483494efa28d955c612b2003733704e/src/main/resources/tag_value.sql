/*
Navicat PGSQL Data Transfer

Source Server         : 70pre
Source Server Version : 90214
Source Host           : 10.0.3.70:5432
Source Database       : hikmuse
Source Schema         : public

Target Server Type    : PGSQL
Target Server Version : 90214
File Encoding         : 65001

Date: 2021-04-12 15:47:41
*/


-- ----------------------------
-- Table structure for tag_value
-- ----------------------------
DROP TABLE IF EXISTS "public"."tag_value";
CREATE TABLE "public"."tag_value" (
"id" int4 NOT NULL,
"second_level_uuid" varchar(255) COLLATE "default" NOT NULL,
"tag_value" varchar(255) COLLATE "default" NOT NULL,
"data_type" varchar(255) COLLATE "default" NOT NULL,
"project_id" int4 NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Alter Sequences Owned By 
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table tag_value
-- ----------------------------
ALTER TABLE "public"."tag_value" ADD PRIMARY KEY ("id");
