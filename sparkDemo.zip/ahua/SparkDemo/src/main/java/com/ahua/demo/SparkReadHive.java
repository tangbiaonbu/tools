package com.ahua.demo;

/**
 * @author 唐少
 * @version 1.0
 * @description: spark 读取hive的表
 * @date 2021/12/5 20:07
 */
public class SparkReadHive {
    public static void main(String[] args) {



    }

}
