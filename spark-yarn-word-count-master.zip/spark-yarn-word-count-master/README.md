# spark-yarn-word-count
A Java example of programmatically launching a Spark job on a MapR cluster with Yarn.
